
class EyeRiskModel(private val context: Context) {
    private val interpreter: Interpreter

    init {
        interpreter = Interpreter(loadModelFile("eye_risk_model.tflite"))
    }

    private fun loadModelFile(modelName: String): MappedByteBuffer {
        val fileDescriptor: AssetFileDescriptor = context.assets.openFd(modelName)
        val inputStream = fileDescriptor.createInputStream()
        val fileChannel = inputStream.channel
        return fileChannel.map(FileChannel.MapMode.READ_ONLY, fileDescriptor.startOffset, fileDescriptor.declaredLength)
    }

    private val symptomMap = listOf(
        "Blurred Vision", "Eye Pain", "Redness", "Itching",
        "Discharge", "Double Vision", "Dryness", "Light Sensitivity"
    )

    fun getEyeRisk(symptoms: List<String>): String {
        val input = FloatArray(symptomMap.size) { i -> if (symptoms.contains(symptomMap[i])) 1.0f else 0.0f }
        val inputBuffer = ByteBuffer.allocateDirect(4 * input.size).order(ByteOrder.nativeOrder())
        input.forEach { inputBuffer.putFloat(it) }
        val outputBuffer = ByteBuffer.allocateDirect(4).order(ByteOrder.nativeOrder())
        inputBuffer.rewind()
        outputBuffer.rewind()
        interpreter.run(inputBuffer, outputBuffer)
        outputBuffer.rewind()
        val output = outputBuffer.float
        return when {
            output < 0.33 -> "Low"
            output < 0.66 -> "Moderate"
            else -> "High"
        }
    }
}
