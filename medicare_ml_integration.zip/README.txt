
# Medicare ML Integration Guide

## Setup Instructions
1. Add TensorFlow Lite dependency to build.gradle:
   implementation 'org.tensorflow:tensorflow-lite:2.13.0'

2. Place .tflite models into: app/src/main/assets/

3. Copy .kt files into your Kotlin package.

4. Use `getHeartRisk(floatArray)` and `getEyeRisk(symptomList)` in your code.

5. Test using provided unit tests if needed.

Models are already trained. No ML knowledge needed.
